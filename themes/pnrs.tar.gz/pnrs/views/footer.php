			

	<!-- footer -->
        <div id="footer">
                <div id="footer-left">
                <img src="http://localhost/pnrs/themes/pnrs/images/ushahidi.png" alt="Powered by the Ushahid Plataform" />
                <img src="http://localhost/pnrs/themes/pnrs/images/ambientalis.png" alt="Ambientalis Engenharia" />
            </div>

            <div id="footer-right">
                <img src="http://localhost/pnrs/themes/pnrs/images/pnuma.png" alt="Pnuma" />
                <img src="http://localhost/pnrs/themes/pnrs/images/mma-brasil.png" alt="Ministério do Meio Ambiente - Brasil" />
            </div>
        </div>
	<!-- / footer -->

</body>
</html>
