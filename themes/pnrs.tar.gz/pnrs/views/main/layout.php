<?php
// Map and Timeline Blocks
echo $div_map;
echo $div_timeline;
?>
