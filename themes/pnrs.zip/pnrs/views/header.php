<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<title><?php echo $page_title.$site_name; ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="<?php echo Kohana::config('core.site_protocol'); ?>://fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700" rel="stylesheet" type="text/css">
	<?php echo $header_block; ?>
		<?php
	// Action::header_scripts - Additional Inline Scripts from Plugins
	Event::run('ushahidi_action.header_scripts');
	?>
</head>



<body id="page" >

<!-- header -->
		<div id="header">
                    <div id="logoimg">
                            <img src="http://localhost/pnrs/themes/pnrs/images/logo-plataforma.png" alt="Resíduos Sólidos - Boas Práticas em Educação Ambiental"/>
                    </div>    
                    <div id="menu">

                        <div id="busca">
                                <form>
                                <input type="text" value="Buscar" onFocus="javascript:this.value=''" />
                            </form>
                        </div>
                        <nav>
                                <ul>
                                <li><a href="<?php echo url::site() . 'main'; ?>">Início</a></li>
                                <li><a href="#" rel="shadowbox">O que é a plataforma</a></li>
                                <li><a href="#">Como participar</a></li>
                                <li><a href="<?php echo url::site().'contact' ?>" class="last">Contato</a></li>
                            </ul>
                        </nav>
                    </div>
		</div>
                <div id="abas">
                        <a href="<?php echo url::site() . 'reports'; ?>" class="bt-ver">Ver práticas</a>
                        <a href="<?php echo url::site() . 'reports/submit'; ?>" class="bt-adicione">Adicione sua prática</a>
                </div>
		<!-- / header -->
  

